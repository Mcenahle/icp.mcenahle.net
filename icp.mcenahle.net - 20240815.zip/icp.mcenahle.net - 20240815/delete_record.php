<!--本文件是 麦ICP备案系统 的一部分。

麦ICP备案系统 是自由软件：你可以再分发之和/或依照由自由软件基金会发布的 GNU 通用公共许可证修改之，无论是版本 3 许可证，还是（按你的决定）任何以后版都可以。

发布 麦ICP备案系统 是希望它能有用，但是并无保障；甚至连可销售和符合某个特定的目的都不保证。请参看 GNU 通用公共许可证，了解详情。

你应该随程序获得一份 GNU 通用公共许可证的副本。如果没有，请看 <https://www.gnu.org/licenses/>。

本程序使用了附加条款。如要获取附加条款，请看 <https://blog.mcenahle.com/2024/07/19/85.html>，或者查看随附的 ADDITIONAL-LICENSE.txt。-->

<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.html");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "record_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM records WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        echo "备案信息删除成功!";
    } else {
        echo "删除失败: " . $conn->error;
    }
} else {
    echo "错误: 未提供备案 ID。";
}

$conn->close();
?>
