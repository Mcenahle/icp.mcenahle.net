<!--本文件是 麦ICP备案系统 的一部分。

麦ICP备案系统 是自由软件：你可以再分发之和/或依照由自由软件基金会发布的 GNU 通用公共许可证修改之，无论是版本 3 许可证，还是（按你的决定）任何以后版都可以。

发布 麦ICP备案系统 是希望它能有用，但是并无保障；甚至连可销售和符合某个特定的目的都不保证。请参看 GNU 通用公共许可证，了解详情。

你应该随程序获得一份 GNU 通用公共许可证的副本。如果没有，请看 <https://www.gnu.org/licenses/>。

本程序使用了附加条款。如要获取附加条款，请看 <https://blog.mcenahle.com/2024/07/19/85.html>，或者查看随附的 ADDITIONAL-LICENSE.txt。-->

<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.html");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "0236beee055b7f3b";
$dbname = "record_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

if (isset($_GET['action']) && isset($_GET['id']) && isset($_GET['record_id'])) {
    $id = intval($_GET['id']);
    $record_id = intval($_GET['record_id']);
    $action = $_GET['action'];

    if ($action == 'approve') {
        $sql_report = "UPDATE reports SET status='已通过' WHERE id='$id'";
        $sql_record = "UPDATE records SET status='确认举报' WHERE id='$record_id'";

        if ($conn->query($sql_report) === TRUE && $conn->query($sql_record) === TRUE) {
            echo "举报信息已通过!";
        } else {
            echo "操作失败: " . $conn->error;
        }
    } elseif ($action == 'reject') {
        $sql_report = "UPDATE reports SET status='已驳回' WHERE id='$id'";
        $sql_record = "UPDATE records SET status='正常' WHERE id='$record_id'";

        if ($conn->query($sql_report) === TRUE && $conn->query($sql_record) === TRUE) {
            echo "举报信息已驳回!";
        } else {
            echo "操作失败: " . $conn->error;
        }
    } elseif ($action == 'delete') {
        $sql = "DELETE FROM reports WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            echo "举报信息已删除!";
        } else {
            echo "操作失败: " . $conn->error;
        }
    }
}

$sql = "SELECT reports.*, records.site_name, records.url FROM reports JOIN records ON reports.record_id = records.id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
        <link rel="icon" type="image/png" href="/favicon.png">
    <title>麦ICP备案系统 - 举报管理</title>
</head>
<body>
    <h1>麦ICP备案系统 - 举报管理</h1>
    <nav>
        <a href="admin_dashboard.php">备案管理</a> | 
        <a href="admin_reports.php">举报管理</a> |
        <a href="https://icp.mcenahle.net">退出登录</a>
    <table border="1">
        <tr>
            <th>举报ID</th>
            <th>网站名</th>
            <th>网址</th>
            <th>举报原因</th>
            <th>状态</th>
            <th>创建时间</th>
            <th>操作</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['site_name'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['url'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['report_reason'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>" . htmlspecialchars($row['created_at'], ENT_QUOTES, 'UTF-8') . "</td>";
                echo "<td>
                        <a href='admin_reports.php?action=approve&id=" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "&record_id=" . htmlspecialchars($row['record_id'], ENT_QUOTES, 'UTF-8') . "'>通过</a> | 
                        <a href='admin_reports.php?action=reject&id=" . htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8') . "&record_id=" . htmlspecialchars($row['record_id'], ENT_QUOTES, 'UTF-8') . "'>驳回</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>暂无举报信息</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
