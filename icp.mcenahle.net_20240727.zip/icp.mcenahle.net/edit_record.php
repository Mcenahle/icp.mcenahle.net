<!--本文件是 麦ICP备案系统 的一部分。

麦ICP备案系统 是自由软件：你可以再分发之和/或依照由自由软件基金会发布的 GNU 通用公共许可证修改之，无论是版本 3 许可证，还是（按你的决定）任何以后版都可以。

发布 麦ICP备案系统 是希望它能有用，但是并无保障；甚至连可销售和符合某个特定的目的都不保证。请参看 GNU 通用公共许可证，了解详情。

你应该随程序获得一份 GNU 通用公共许可证的副本。如果没有，请看 <https://www.gnu.org/licenses/>。

本程序使用了附加条款。如要获取附加条款，请看 <https://blog.mcenahle.com/2024/07/19/85.html>，或者查看随附的 ADDITIONAL-LICENSE.txt。-->

<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.html");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "0236beee055b7f3b";
$dbname = "record_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $site_name = $_POST['site_name'];
        $email = $_POST['email'];
        $url = $_POST['url'];
        $site_description = $_POST['site_description'];

        $sql = "UPDATE records SET site_name='$site_name', email='$email', url='$url', site_description='$site_description' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo "备案信息更新成功!";
        } else {
            echo "更新失败: " . $conn->error;
        }
    }

    $sql = "SELECT * FROM records WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "未找到此备案信息";
        exit;
    }
} else {
    echo "错误: 未提供备案 ID。";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>麦ICP备案系统 - 修改备案信息</title>
</head>
<body>
    <h1>麦ICP备案系统 - 修改备案信息</h1>
    <form method="post" action="edit_record.php?id=<?php echo $id; ?>">
        <label for="site_name">网站名:</label>
        <input type="text" id="site_name" name="site_name" value="<?php echo $row['site_name']; ?>" required><br><br>
        <label for="email">邮箱:</label>
        <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>
        <label for="url">网址:</label>
        <input type="url" id="url" name="url" value="<?php echo $row['url']; ?>" required><br><br>
        <label for="site_description">网站描述:</label>
        <textarea id="site_description" name="site_description" required><?php echo $row['site_description']; ?></textarea><br><br>
        <input type="submit" value="更新">
    </form>
</body>
</html>
