<!--本文件是 麦ICP备案系统 的一部分。

麦ICP备案系统 是自由软件：你可以再分发之和/或依照由自由软件基金会发布的 GNU 通用公共许可证修改之，无论是版本 3 许可证，还是（按你的决定）任何以后版都可以。

发布 麦ICP备案系统 是希望它能有用，但是并无保障；甚至连可销售和符合某个特定的目的都不保证。请参看 GNU 通用公共许可证，了解详情。

你应该随程序获得一份 GNU 通用公共许可证的副本。如果没有，请看 <https://www.gnu.org/licenses/>。

本程序使用了附加条款。如要获取附加条款，请看 <https://blog.mcenahle.com/2024/07/19/85.html>，或者查看随附的 ADDITIONAL-LICENSE.txt。-->

<?php
$servername = "localhost";
$username = "root";
$password = "0236beee055b7f3b";
$dbname = "record_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

$id = "";
$record = null;

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM records WHERE id='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $record = $result->fetch_assoc();
    } else {
        echo "未找到匹配的备案信息";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_reason']) && isset($_POST['record_id'])) {
    $record_id = $_POST['record_id'];
    $report_reason = $_POST['report_reason'];

    $sql_report = "INSERT INTO reports (record_id, report_reason) VALUES ('$record_id', '$report_reason')";
    $sql_status = "UPDATE records SET status='待确认举报' WHERE id='$record_id'";

    if ($conn->query($sql_report) === TRUE && $conn->query($sql_status) === TRUE) {
        echo "举报提交成功!";
    } else {
        echo "提交失败: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>麦ICP备案系统 - 查询备案信息</title>
        <link rel="icon" type="image/png" href="/favicon.png">
    <link href="https://cdn.staticfile.net/twitter-bootstrap/5.1.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.staticfile.net/twitter-bootstrap/5.1.1/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <h1>麦ICP备案系统 - 查询备案信息</h1>
    <form method="get" action="query_record.php">
        <label for="id">网站ID:</label>
        <input type="text" id="id" name="id" value="<?php echo htmlspecialchars($id); ?>" required disabled>
        <!--<input type="submit" value="查询">-->
        <button type="button" class="btn btn-primary" value="查询" disabled>查询</button>
        <div>如要修改查询，请将网站域名中原有的查询ID换成新的。或者也可以转到首页，然后再次执行一次查询。</div>
        <br>
    </form>

    <?php if ($record): ?>
    <h2>备案信息查询结果如下：</h2>
    <table border="1" table class="table table-striped">
        <tr>
            <th>ID</th>
            <th>网站名</th>
            <th>邮箱</th>
            <th>网址</th>
            <th>网站描述</th>
            <th>状态</th>
            <th>创建时间</th>
            <th>操作</th>
        </tr>
        <tr>
            <td><?php echo $record['id']; ?></td>
            <td><?php echo $record['site_name']; ?></td>
            <td><?php echo $record['email']; ?></td>
            <td><?php echo $record['url']; ?></td>
            <td><?php echo $record['site_description']; ?></td>
            <td><?php echo $record['status']; ?></td>
            <td><?php echo $record['created_at']; ?></td>
            <td>
                <form method="post" action="query_record.php">
                    <input type="hidden" name="record_id" value="<?php echo $record['id']; ?>">
                    <input type="text" name="report_reason" placeholder="举报原因" required>
                    <input type="submit" value="举报">
                </form>
            </td>
        </tr>
    </table>
    <?php endif; ?>
        <a href=https://icp.mcenahle.net><input type="button" class="btn btn-link" value="返回首页"></a>
    <div>&copy; 2024 Mcenahle。</div>
</body>
</html>

<?php
$conn->close();
?>
